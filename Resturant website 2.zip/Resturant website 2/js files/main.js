document.addEventListener('DOMContentLoaded', function() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const menuItems = document.querySelectorAll('.menu-item');

    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const category = this.getAttribute('data-category');

            menuItems.forEach(item => {
                if (category === 'all' || item.getAttribute('data-category') === category) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });
});
window.addEventListener('scroll', function() {
    const aboutSection = document.getElementById('about');
    const navbar = document.querySelector('.navbar');
    const aboutSectionTop = aboutSection.offsetTop;
    const scrollPosition = window.scrollY;

    if (scrollPosition >= aboutSectionTop) {
        navbar.classList.add('navbar-dark-text');
    } else {
        navbar.classList.remove('navbar-dark-text');
    }
});
document.getElementById('newsletter-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const email = document.getElementById('newsletter-email').value;
    
    if (validateEmail(email)) {
        alert('Thank you for subscribing!');
        // You can add an AJAX call here to send the email to the server
        document.getElementById('newsletter-email').value = ''; // Clear the input field
    } else {
        alert('Please enter a valid email address.');
    }
});

function validateEmail(email) {
    const re = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]{2,}$/;
    return re.test(String(email).toLowerCase());
}
