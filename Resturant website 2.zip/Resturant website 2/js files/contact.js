// Initialize and add the map
function initMap() {
    // The location of Hyderabad, Pakistan
    var hyderabad = {lat: 25.39242, lng: 68.37366}; 
    // The map, centered at Hyderabad
    var map = new google.maps.Map(
        document.getElementById('map'), {zoom: 15, center: hyderabad});
    // The marker, positioned at Hyderabad
    var marker = new google.maps.Marker({position: hyderabad, map: map});
}

// Load the map
window.onload = initMap;
